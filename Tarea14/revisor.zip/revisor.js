const PAGE_BODY = `<section class="section">
      <div class="card">
        <header class="card-header">
          <p class="card-header-title">Súper Fresco - Catálogo</p>
        </header>

        <div class="card-content">
          <form id="form-buscar" class="buscador">
            <input type="text" id="input-buscar" placeholder="Buscar producto... (ej. milk)" />
            <button type="submit">Buscar</button>
          </form>

          <p id="mensaje-carga" class="mensaje-carga"></p>
          <p id="mensaje-error" class="mensaje-error"></p>

          <ul id="lista-productos" class="products-list">
            <!-- Los <li> se pintan en el JS a partir de lo que regrese la API -->
          </ul>
        </div>

        <footer class="card-footer">
          <p class="instructions">Catálogo cargado en vivo desde una API real (dummyjson.com).</p>
        </footer>
      </div>
    </section>`;

const PAGE_CSS = `* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: "Segoe UI", Roboto, system-ui, sans-serif;
  background-color: #eef3f0;
}

.section {
  display: flex;
  justify-content: center;
  padding: 2.5rem 1rem;
  min-height: 100vh;
}

.card {
  width: 100%;
  max-width: 38rem;
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
  overflow: hidden;
}

.card-header {
  background-color: #2e7d32;
  text-align: center;
  padding: 0.75rem 0;
}

.card-header-title {
  color: white;
  font-size: 1.25rem;
  font-weight: 600;
  margin: 0;
}

.card-content {
  padding: 1.5rem;
}

.card-footer {
  padding: 0.75rem 1.5rem 1.25rem;
  text-align: center;
}

.instructions {
  color: #666;
  font-size: 0.85rem;
  margin: 0;
}

.buscador {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.buscador input {
  flex: 1;
  padding: 0.5rem 0.7rem;
  border: 1px solid #ccc;
  border-radius: 6px;
}

.buscador button {
  border: none;
  background-color: #2e7d32;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 6px;
  cursor: pointer;
}

.buscador button:hover {
  background-color: #276529;
}

.mensaje-carga {
  color: #8a6d00;
  background-color: #fff8e1;
  padding: 0.6rem 0.9rem;
  border-radius: 8px;
  margin-bottom: 1rem;
}

.mensaje-carga:empty {
  display: none;
}

.mensaje-error {
  color: #c62828;
  background-color: #fdecea;
  padding: 0.6rem 0.9rem;
  border-radius: 8px;
  margin-bottom: 1rem;
  font-weight: bold;
}

.mensaje-error:empty {
  display: none;
}

.products-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.producto {
  display: flex;
  gap: 0.9rem;
  background: #f7faf7;
  border: 1px solid #dde8de;
  border-radius: 10px;
  padding: 0.7rem 0.9rem;
}

.producto img {
  width: 64px;
  height: 64px;
  object-fit: cover;
  border-radius: 8px;
  flex-shrink: 0;
  background: #e5e5e5;
}

.producto-info {
  display: flex;
  flex-direction: column;
  gap: 0.15rem;
  min-width: 0;
}

.producto-nombre {
  font-size: 0.95rem;
  font-weight: 600;
}

.producto-marca {
  font-size: 0.78rem;
  color: #666;
}

.producto-precio {
  font-size: 0.85rem;
  color: #2e7d32;
  font-weight: bold;
}

.producto-rating {
  font-size: 0.8rem;
  color: #b5651d;
}

.producto-codigo {
  font-size: 0.72rem;
  color: #999;
  font-family: Consolas, monospace;
}
`;

function buildSandbox(studentJS, mockResponses) {
  return new Promise((resolve, reject) => {
    const sandbox = document.querySelector("#sandbox");
    const iframe = document.createElement("iframe");

    const mockScript = `
      (function () {
        const __responses = ${JSON.stringify(mockResponses || [{ ok: true, status: 200, data: { products: [] } }])};
        let __callIndex = 0;
        window.__fetchCalls = [];
        window.fetch = function (url) {
          window.__fetchCalls.push(String(url));
          const spec = __responses[Math.min(__callIndex, __responses.length - 1)];
          __callIndex++;
          if (spec.networkError) {
            return Promise.reject(new TypeError("Failed to fetch"));
          }
          return Promise.resolve({
            ok: spec.ok,
            status: spec.status,
            json: function () { return Promise.resolve(spec.data); },
          });
        };
      })();
    `;

    const fullDoc = `<!doctype html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <style>${PAGE_CSS}</style>
  </head>
  <body>
    ${PAGE_BODY}
    <script>
      window.onerror = function (msg) {
        window.parent.postMessage({ type: "sandbox-error", message: msg }, "*");
      };
      ${mockScript}
    <\/script>
    <script>
${studentJS}
    <\/script>
    <script>
      window.parent.postMessage({ type: "sandbox-ready" }, "*");
    <\/script>
  </body>
</html>`;

    const onMessage = (event) => {
      if (!event.data || event.source !== iframe.contentWindow) return;

      if (event.data.type === "sandbox-error") {
        window.removeEventListener("message", onMessage);
        reject(new Error("Error al cargar el código: " + event.data.message));
      } else if (event.data.type === "sandbox-ready") {
        window.removeEventListener("message", onMessage);
        resolve(iframe.contentDocument);
      }
    };
    window.addEventListener("message", onMessage);

    sandbox.appendChild(iframe);
    iframe.srcdoc = fullDoc;
  });
}

async function wait(ms = 50) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ===== Datos falsos para las pruebas (no vienen de internet) =====

function productoFalso(extra) {
  return Object.assign(
    {
      id: 1,
      title: "Producto De Prueba",
      price: 9.99,
      brand: "MarcaX",
      category: "groceries",
      images: ["https://example.com/img.png"],
      thumbnail: "https://example.com/thumb.png",
      meta: { barcode: "1112223334445" },
      reviews: [{ rating: 4 }, { rating: 5 }, { rating: 3 }],
    },
    extra
  );
}

const pruebas = [
  {
    id: "P1",
    nombre: "cargarCatalogo: regresa data.products si la API responde bien, y lanza Error con el status si no (res.ok)",
    puntos: 20,
    async ejecutar(codigo) {
      // Caso éxito: la API "responde" con 2 productos falsos.
      const docOk = await buildSandbox(codigo, [
        { ok: true, status: 200, data: { products: [productoFalso({ id: 1 }), productoFalso({ id: 2 })] } },
      ]);
      const resultado = await docOk.defaultView.cargarCatalogo();
      if (!Array.isArray(resultado) || resultado.length !== 2) {
        throw new Error(`cargarCatalogo() debería regresar el arreglo data.products (2 elementos); regresó: ${JSON.stringify(resultado)}.`);
      }

      const docError = await buildSandbox(codigo, [{ ok: false, status: 404, data: {} }]);
      let lanzoError = false;
      let mensaje = "";
      try {
        await docError.defaultView.cargarCatalogo();
      } catch (e) {
        lanzoError = true;
        mensaje = e.message || "";
      }
      if (!lanzoError) {
        throw new Error("Con response.ok === false (404), cargarCatalogo() debería lanzar/rechazar con un Error, y no regresar datos normalmente.");
      }
      if (!mensaje.includes("404")) {
        throw new Error(`El error debería incluir el status (404) en el mensaje para que sea útil; el mensaje fue: "${mensaje}".`);
      }
      return true;
    },
  },
  {
    id: "P2",
    nombre: "textoRating regresa el texto del promedio (\"Rating 4.0\") y \"Sin calificaciones\" si no hay reviews",
    puntos: 20,
    async ejecutar(codigo) {
      const doc = await buildSandbox(codigo, []);
      const win = doc.defaultView;

      const texto = String(win.textoRating([{ rating: 4 }, { rating: 5 }, { rating: 3 }]));
      if (!texto.includes("4.0")) {
        throw new Error(`textoRating([{rating:4},{rating:5},{rating:3}]) debería regresar el texto "Rating 4.0" (promedio con un decimal, toFixed(1)); regresó ${JSON.stringify(texto)}.`);
      }

      const vacio = String(win.textoRating([]));
      if (!vacio.toLowerCase().includes("sin calificaciones")) {
        throw new Error(`textoRating([]) (sin reviews) debería regresar "Sin calificaciones"; regresó ${JSON.stringify(vacio)}.`);
      }
      return true;
    },
  },
  {
    id: "P3",
    nombre: "crearElementoProducto muestra marca (o 'Genérico'), el rating promedio (o 'sin calificaciones') y el código de barras anidado",
    puntos: 20,
    async ejecutar(codigo) {
      const doc = await buildSandbox(codigo, []);
      const win = doc.defaultView;

      const conTodo = productoFalso({ brand: "Lala", reviews: [{ rating: 4 }, { rating: 2 }], meta: { barcode: "9998887776665" } });
      const li1 = win.crearElementoProducto(conTodo);
      const texto1 = li1.textContent;
      if (!texto1.includes("Lala")) {
        throw new Error(`No se muestra la marca ("Lala") del producto. Texto generado: "${texto1}".`);
      }
      if (!texto1.includes("3.0")) {
        throw new Error(`El promedio de [4, 2] es 3; se esperaba "3.0" (texto de textoRating) en el texto generado: "${texto1}".`);
      }
      if (!texto1.includes("9998887776665")) {
        throw new Error(`No se muestra el código de barras (producto.meta.barcode). Texto generado: "${texto1}".`);
      }

      const sinMarcaNiReviews = productoFalso({ brand: null, reviews: [] });
      const li2 = win.crearElementoProducto(sinMarcaNiReviews);
      const texto2 = li2.textContent.toLowerCase();
      if (!texto2.includes("genérico") && !texto2.includes("generico")) {
        throw new Error(`Cuando producto.brand es null, se esperaba el texto "Genérico"; texto generado: "${li2.textContent}".`);
      }
      if (!(texto2.includes("sin calificaciones") || texto2.includes("sin calificación"))) {
        throw new Error(`Cuando producto.reviews está vacío, se esperaba algo como "Sin calificaciones"; texto generado: "${li2.textContent}".`);
      }
      return true;
    },
  },
  {
    id: "P4",
    nombre: "pintarProductos limpia la lista anterior y pinta exactamente un elemento por producto",
    puntos: 20,
    async ejecutar(codigo) {
      const doc = await buildSandbox(codigo, []);
      const win = doc.defaultView;
      const lista = doc.querySelector("#lista-productos");

      win.pintarProductos([productoFalso({ id: 1 }), productoFalso({ id: 2 }), productoFalso({ id: 3 })]);
      if (lista.children.length !== 3) {
        throw new Error(`Con 3 productos se esperaban 3 elementos en #lista-productos; hay ${lista.children.length}.`);
      }

      win.pintarProductos([productoFalso({ id: 4 })]);
      if (lista.children.length !== 1) {
        throw new Error(`pintarProductos debe limpiar lo anterior antes de pintar: tras pintar 1 producto quedaron ${lista.children.length} elementos (se acumularon los de la llamada anterior).`);
      }
      return true;
    },
  },
  {
    id: "P5",
    nombre: "init() usa try/catch/finally (y se ejecuta con DOMContentLoaded): pinta el catálogo o muestra el error, y siempre oculta el mensaje de 'cargando'",
    puntos: 20,
    async ejecutar(codigo) {
      // Caso éxito.
      const docOk = await buildSandbox(codigo, [
        { ok: true, status: 200, data: { products: [productoFalso({ id: 1 }), productoFalso({ id: 2 })] } },
      ]);
      await wait(150);
      const listaOk = docOk.querySelector("#lista-productos");
      const cargaOk = docOk.querySelector("#mensaje-carga").textContent.trim();
      const errorOk = docOk.querySelector("#mensaje-error").textContent.trim();
      if (listaOk.children.length !== 2) {
        throw new Error(`Tras init() con la API respondiendo bien, se esperaban 2 productos pintados; hay ${listaOk.children.length}.`);
      }
      if (cargaOk !== "") {
        throw new Error(`Tras terminar init() (éxito), el mensaje de "Cargando..." debería quedar vacío (finally -> ocultarCargando); quedó: "${cargaOk}".`);
      }
      if (errorOk !== "") {
        throw new Error(`No debería haber mensaje de error en el caso de éxito; se mostró: "${errorOk}".`);
      }

      // Caso de falla de red (sin conexión / API caída).
      const docFalla = await buildSandbox(codigo, [{ networkError: true }]);
      await wait(150);
      const cargaFalla = docFalla.querySelector("#mensaje-carga").textContent.trim();
      const errorFalla = docFalla.querySelector("#mensaje-error").textContent.trim();
      if (cargaFalla !== "") {
        throw new Error(`Tras una falla de red, el mensaje de "Cargando..." debería quedar vacío igualmente (finally); quedó: "${cargaFalla}".`);
      }
      if (errorFalla === "") {
        throw new Error("Tras una falla de red, se esperaba que init() mostrara un mensaje de error (catch -> mostrarError), pero #mensaje-error quedó vacío.");
      }
      return true;
    },
  },
];

// ============================================================
// UI — checkbox (gris/rojo/verde) por punto, barra de progreso,
// botón para procesar todo, y botón "Probar" por punto.
// ============================================================

let score = null;
let barFill = null;

function construirChecklist() {
  const lista = document.getElementById("checklist");
  lista.innerHTML = "";
  pruebas.forEach((prueba) => {
    const li = document.createElement("li");
    li.className = "punto";
    li.innerHTML = `
      <button class="btnProbarUna" data-id="${prueba.id}">Probar</button>
      <input type="checkbox" />
      <label id="${prueba.id}">${prueba.nombre} (${prueba.puntos} pts)</label>
    `;
    lista.appendChild(li);
  });

  lista.querySelectorAll(".btnProbarUna").forEach((boton) => {
    boton.addEventListener("click", () => probarUna(boton.dataset.id));
  });
}

async function resetScore() {
  score.textContent = "0";
  barFill.style.width = "0%";
  document.querySelectorAll('#checklist input[type="checkbox"]').forEach((checkbox) => {
    checkbox.disabled = true;
    checkbox.checked = false;
  });
  document.querySelectorAll(".error-message").forEach((el) => el.remove());
  document.querySelector("#sandbox").innerHTML = "";
}

function marcarResultado(id, paso, mensajeError) {
  const label = document.querySelector(`#${id}`);
  const checkbox = label ? label.previousElementSibling : null;
  const previoError = label && label.nextElementSibling && label.nextElementSibling.classList.contains("error-message") ? label.nextElementSibling : null;
  if (previoError) previoError.remove();

  if (checkbox) {
    checkbox.disabled = true;
    checkbox.checked = paso;
  }
  if (!paso && mensajeError && label) {
    const errorDiv = document.createElement("div");
    errorDiv.classList.add("error-message");
    errorDiv.style.color = "red";
    errorDiv.textContent = mensajeError;
    label.insertAdjacentElement("afterend", errorDiv);
  }
}

function actualizarScore() {
  const total = pruebas.reduce((suma, prueba) => {
    const label = document.querySelector(`#${prueba.id}`);
    const checkbox = label ? label.previousElementSibling : null;
    return suma + (checkbox && checkbox.checked ? prueba.puntos : 0);
  }, 0);
  score.textContent = total;
  barFill.style.width = total + "%";
}

function leerCodigoFuente() {
  const codigo = document.getElementById("codeInput").value;
  return codigo.trim() ? codigo : null;
}

async function probarUna(id) {
  const codigoFuente = leerCodigoFuente();
  if (!codigoFuente) {
    alert("Sube el archivo catalogo.js o pega el código en el cuadro de texto.");
    return;
  }
  const prueba = pruebas.find((p) => p.id === id);
  let paso = false;
  let error = "";
  try {
    paso = Boolean(await prueba.ejecutar(codigoFuente));
  } catch (e) {
    error = e.message;
  }
  marcarResultado(id, paso, error);
  actualizarScore();
}

async function procesarTodo() {
  const codigoFuente = leerCodigoFuente();
  if (!codigoFuente) {
    alert("Por favor, pega tu código en el área de texto.");
    return;
  }
  await resetScore();
  for (const prueba of pruebas) {
    let paso = false;
    let error = "";
    try {
      paso = Boolean(await prueba.ejecutar(codigoFuente));
    } catch (e) {
      error = e.message;
    }
    marcarResultado(prueba.id, paso, error);
    actualizarScore();
  }
}

document.addEventListener("DOMContentLoaded", () => {
  score = document.querySelector("#score");
  barFill = document.querySelector("#progress-bar-fill");
  construirChecklist();
  resetScore();

  document.getElementById("processCodeButton").addEventListener("click", procesarTodo);

  document.getElementById("fileinput").addEventListener("change", async (evt) => {
    const archivo = evt.target.files[0];
    if (!archivo) return;
    if (!archivo.name.toLowerCase().endsWith(".js")) {
      alert("Solo se aceptan archivos .js");
      evt.target.value = "";
      return;
    }
    document.getElementById("codeInput").value = await archivo.text();
    await procesarTodo();
  });
});
