// ===== Markup y CSS fijos de la tarea (los que ya tienen los alumnos) =====
// Se usan para armar, dentro de un iframe oculto, una página completa junto
// con el checkout.js que suba o pegue el alumno.

const PAGE_BODY = `<section class="section">
      <div class="layout">
      <div class="card">
        <header class="card-header">
          <p class="card-header-title">Checkout - Súper Fresco</p>
        </header>

        <div class="card-content">
          <ul id="lista-productos" class="products-list">
            <!-- Los <li> se pintan en el JS a partir de productosDisponibles -->
          </ul>

          <div class="checkout-panel" id="panel-checkout" hidden>
            <h2 class="checkout-title">Finalizar compra</h2>
            <p id="producto-seleccionado" class="producto-seleccionado"></p>

            <div class="form-row">
              <label for="input-cantidad">Cantidad</label>
              <input type="number" id="input-cantidad" min="1" value="1" />
            </div>

            <p id="total-compra" class="total-compra"></p>

            <div class="form-row">
              <label for="select-metodo-pago">Método de pago</label>
              <select id="select-metodo-pago">
                <option value="tarjeta">Tarjeta</option>
                <option value="paypal">PayPal</option>
              </select>
            </div>

            <div class="form-row" id="label-tarjeta">
              <label for="input-tarjeta">Número de tarjeta (16 dígitos)</label>
              <input type="text" id="input-tarjeta" placeholder="4242424242424242" />
            </div>

            <button id="btn-finalizar">Finalizar compra</button>

            <div id="estado-checkout" class="estado" aria-live="polite"></div>
          </div>
        </div>

        <footer class="card-footer">
          <p class="instructions">Selecciona un producto, completa tus datos de pago y finaliza la compra.</p>
        </footer>
      </div>

      <aside class="card info-panel">
        <header class="card-header">
          <p class="card-header-title">Cómo funciona el cobro</p>
        </header>
        <div class="card-content">
          <ul class="info-list">
            <li>Tarjeta: válida solo con 16 dígitos exactos.</li>
            <li>Probabilidad de que falle el cobro — PayPal: <strong>40%</strong>, Tarjeta: <strong>20%</strong>.</li>
            <li>Duración del cobro: aleatoria, entre 0.3s y 6s.</li>
            <li>Límite de tiempo (timeout): <strong>5s</strong>. Si el cobro no responde antes, se cancela por tardanza (puede pasar, ya que la duración llega hasta 6s).</li>
          </ul>
          <p id="tiempo-pago" class="tiempo-pago"></p>
        </div>
      </aside>
      </div>
    </section>`;

const PAGE_CSS = `* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: "Segoe UI", Roboto, system-ui, sans-serif;
  background-color: #eef3f0;
}

.section {
  display: flex;
  justify-content: center;
  padding: 2.5rem 1rem;
  min-height: 100vh;
}

.layout {
  display: flex;
  flex-wrap: wrap;
  gap: 1.5rem;
  align-items: flex-start;
  justify-content: center;
}

.info-panel {
  max-width: 20rem;
}

.info-list {
  margin: 0;
  padding-left: 1.1rem;
  font-size: 0.85rem;
  color: #333;
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}

.tiempo-pago {
  margin: 1rem 0 0;
  font-size: 0.85rem;
  font-weight: bold;
  color: #8a6d00;
  min-height: 1.2rem;
}

.card {
  width: 100%;
  max-width: 34rem;
  background-color: white;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
  overflow: hidden;
}

.card-header {
  background-color: #2e7d32;
  text-align: center;
  padding: 0.75rem 0;
}

.card-header-title {
  color: white;
  font-size: 1.25rem;
  font-weight: 600;
  margin: 0;
}

.card-content {
  padding: 1.5rem;
}

.card-footer {
  padding: 0.75rem 1.5rem 1.25rem;
  text-align: center;
}

.instructions {
  color: #666;
  font-size: 0.85rem;
  margin: 0;
}

.products-list {
  list-style: none;
  margin: 0 0 1rem;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}

.producto {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #f7faf7;
  border: 1px solid #dde8de;
  border-radius: 10px;
  padding: 0.7rem 0.9rem;
}

.producto .info strong {
  display: block;
  font-size: 0.95rem;
}

.producto .precio {
  color: #666;
  font-size: 0.85rem;
}

.producto .sin-stock {
  color: #c62828;
  font-size: 0.8rem;
  font-weight: bold;
}

.producto .stock {
  color: #2e7d32;
  font-size: 0.8rem;
}

.producto button {
  border: none;
  background-color: #2e7d32;
  color: white;
  padding: 0.45rem 0.9rem;
  border-radius: 20px;
  cursor: pointer;
  font-size: 0.85rem;
}

.producto button:hover {
  background-color: #256428;
}

.producto button:disabled {
  background-color: #b7c9b8;
  cursor: not-allowed;
}

.checkout-panel {
  border-top: 1px solid #eee;
  padding-top: 1.25rem;
}

.checkout-title {
  margin: 0 0 0.75rem;
  font-size: 1.05rem;
  color: #2e7d32;
}

.producto-seleccionado {
  font-size: 0.9rem;
  color: #333;
  margin: 0 0 0.75rem;
}

.form-row {
  margin-bottom: 0.75rem;
}

.total-compra {
  margin: -0.25rem 0 0.75rem;
  font-weight: bold;
  color: #2e7d32;
}

.form-row label {
  display: block;
  font-size: 0.85rem;
  margin-bottom: 0.3rem;
}

.form-row input,
.form-row select {
  width: 100%;
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 6px;
}

#btn-finalizar {
  margin-top: 0.5rem;
  border: none;
  background-color: #2e7d32;
  color: white;
  padding: 0.6rem 1.2rem;
  border-radius: 20px;
  cursor: pointer;
  font-size: 0.95rem;
}

#btn-finalizar:disabled {
  background-color: #9ccb9f;
  cursor: wait;
}

.estado {
  margin-top: 1rem;
  padding: 0.6rem 0.9rem;
  border-radius: 8px;
  font-size: 0.9rem;
  min-height: 1.2rem;
}

.estado:empty {
  display: none;
}

.estado.cargando {
  background-color: #fff8e1;
  color: #8a6d00;
}

.estado.exito {
  background-color: #e8f5e9;
  color: #2e7d32;
  font-weight: bold;
}

.estado.error {
  background-color: #fdecea;
  color: #c62828;
  font-weight: bold;
}
`;

// ===== Sandbox: monta HTML+CSS fijos + JS del alumno en un iframe oculto =====
// Cada prueba construye SU PROPIO sandbox desde cero, y puede fijar
// Math.random (mockRandom) para que el resultado del cobro (monto de la
// demora y si falla o no) sea predecible y la prueba no sea un volado.

function buildSandbox(studentJS, mockRandom) {
  return new Promise((resolve, reject) => {
    const sandbox = document.querySelector("#sandbox");
    const iframe = document.createElement("iframe");

    const mockScript =
      typeof mockRandom === "number"
        ? `Math.random = function () { return ${mockRandom}; };`
        : "";

    const fullDoc = `<!doctype html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <style>${PAGE_CSS}</style>
  </head>
  <body>
    ${PAGE_BODY}
    <script>
      window.onerror = function (msg) {
        window.parent.postMessage({ type: "sandbox-error", message: msg }, "*");
      };
      ${mockScript}
    <\/script>
    <script>
${studentJS}
    <\/script>
    <script>
      window.parent.postMessage({ type: "sandbox-ready" }, "*");
    <\/script>
  </body>
</html>`;

    const onMessage = (event) => {
      if (!event.data || event.source !== iframe.contentWindow) return;

      if (event.data.type === "sandbox-error") {
        window.removeEventListener("message", onMessage);
        reject(new Error("Error al cargar el código: " + event.data.message));
      } else if (event.data.type === "sandbox-ready") {
        window.removeEventListener("message", onMessage);
        resolve(iframe.contentDocument);
      }
    };
    window.addEventListener("message", onMessage);

    sandbox.appendChild(iframe);
    iframe.srcdoc = fullDoc;
  });
}

// ===== Helpers para simular al usuario sobre el iframe =====

function click(el) {
  el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
}

function setValue(el, value) {
  el.value = value;
  el.dispatchEvent(new Event("input", { bubbles: true }));
}

function changeSelect(el, value) {
  el.value = value;
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

async function wait(ms = 50) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Selecciona el producto por índice (0 = café 500g, 1 = café 1kg, 2 = café 5kg)
// dando clic en su botón "Comprar", y llena cantidad/método/tarjeta.
async function iniciarCompra(doc, { indiceProducto = 0, cantidad = 1, metodo = "paypal", tarjeta = "" } = {}) {
  const botones = Array.from(doc.querySelectorAll(".producto button"));
  const boton = botones[indiceProducto];
  if (!boton) throw new Error(`No se encontró el botón "Comprar" del producto índice ${indiceProducto}.`);
  click(boton);
  await wait();

  const panel = doc.querySelector("#panel-checkout");
  if (panel.hidden) throw new Error("El panel de checkout no se mostró al seleccionar el producto.");

  setValue(doc.querySelector("#input-cantidad"), String(cantidad));
  changeSelect(doc.querySelector("#select-metodo-pago"), metodo);
  if (metodo === "tarjeta") {
    setValue(doc.querySelector("#input-tarjeta"), tarjeta);
  }
  await wait();
  return doc;
}

function estadoTexto(doc) {
  return doc.querySelector("#estado-checkout").textContent.trim();
}

function estadoClase(doc) {
  return doc.querySelector("#estado-checkout").className;
}

/**
 * Cada prueba monta su propio sandbox y regresa true, o lanza un Error
 * con el detalle de qué falló. Los puntos suman 100.
 *
 * mockRandom fija Math.random() dentro del iframe para controlar, de forma
 * determinista, la demora y el éxito/fracaso del cobro simulado en
 * procesarPago(monto, metodo, senal):
 *   demora = 300 + Math.random() * 5700   (0.3s a 6s)
 *   falla si Math.random() < 0.4 (paypal) o < 0.2 (tarjeta)
 */
const pruebas = [
  {
    id: "P1",
    nombre: "Promise.all corre verificarStock y validarMetodoPago en paralelo, y una tarjeta inválida detiene todo con su mensaje",
    puntos: 20,
    async ejecutar(codigo) {
      const doc = await buildSandbox(codigo, 0.5);
      await iniciarCompra(doc, { indiceProducto: 0, cantidad: 1, metodo: "tarjeta", tarjeta: "123" });

      click(doc.querySelector("#btn-finalizar"));
      const inicio = performance.now();
      await wait(750);
      const transcurrido = performance.now() - inicio;

      const texto = estadoTexto(doc).toLowerCase();
      if (!texto.includes("tarjeta")) {
        throw new Error(`Con una tarjeta de 3 dígitos se esperaba un mensaje sobre la tarjeta inválida; el estado mostrado fue: "${estadoTexto(doc)}".`);
      }
      // verificarStock y validarMetodoPago tardan 500ms cada una (dadas). Si
      // se corrieran en SERIE (uno esperando al otro) tardarían ~1000ms en
      // total antes de poder mostrar el error; en PARALELO (Promise.all)
      // el error aparece apenas a los ~500ms.
      if (transcurrido > 900) {
        throw new Error(`El error de tarjeta tardó ${Math.round(transcurrido)}ms en aparecer; verificarStock y validarMetodoPago deberían correr en paralelo con Promise.all (~500ms), no uno tras otro (~1000ms).`);
      }
      return true;
    },
  },
  {
    id: "P2",
    nombre: "Si no hay stock suficiente, se detiene con el mensaje de stock",
    puntos: 10,
    async ejecutar(codigo) {
      const doc = await buildSandbox(codigo, 0.5);
      // Café 500g tiene stock inicial 8; se pide más del disponible.
      await iniciarCompra(doc, { indiceProducto: 0, cantidad: 50, metodo: "paypal" });

      click(doc.querySelector("#btn-finalizar"));
      await wait(750);

      const texto = estadoTexto(doc).toLowerCase();
      if (!(texto.includes("stock") || texto.includes("no hay"))) {
        throw new Error(`Al pedir más cantidad de la que hay en stock se esperaba un mensaje de stock insuficiente; el estado mostrado fue: "${estadoTexto(doc)}".`);
      }
      if (!estadoClase(doc).includes("error")) {
        throw new Error("El mensaje de stock insuficiente no se mostró con la clase de error (estado error).");
      }
      return true;
    },
  },
  {
    id: "P3",
    nombre: "Promise.race: si el cobro tarda más que el límite de 5s, se cancela por tardanza",
    puntos: 15,
    async ejecutar(codigo) {
      // Math.random = 0.99 -> demora = 300 + 0.99*5700 ≈ 5943ms (> 5000ms
      // del límite) y 0.99 no es menor que la probabilidad de fallo
      // (0.4 o 0.2), así que procesarPago NO rechaza por sí mismo: si el
      // checkout falla aquí, tiene que ser porque ganó el timeout.
      const doc = await buildSandbox(codigo, 0.99);
      await iniciarCompra(doc, { indiceProducto: 0, cantidad: 1, metodo: "paypal" });

      click(doc.querySelector("#btn-finalizar"));
      await wait(5700);

      const texto = estadoTexto(doc).toLowerCase();
      if (!(texto.includes("tardó") || texto.includes("demasiado") || texto.includes("tiempo"))) {
        throw new Error(`Con un cobro forzado a durar ~5.9s (más que el límite de 5s) se esperaba el mensaje de tiempo agotado; el estado mostrado fue: "${estadoTexto(doc)}".`);
      }
      return true;
    },
  },
  {
    id: "P4",
    nombre: "Si el cobro es rechazado (no por tiempo), se muestra el mensaje de error del cobro",
    puntos: 15,
    async ejecutar(codigo) {
      // Math.random = 0 -> demora = 300ms (rápida, no hay riesgo de
      // timeout) y 0 SÍ es menor que la probabilidad de fallo (0.4 o
      // 0.2), así que procesarPago rechaza.
      const doc = await buildSandbox(codigo, 0);
      await iniciarCompra(doc, { indiceProducto: 0, cantidad: 1, metodo: "paypal" });

      click(doc.querySelector("#btn-finalizar"));
      await wait(900);

      const texto = estadoTexto(doc).toLowerCase();
      if (texto.includes("confirmado")) {
        throw new Error("El cobro debía fallar (se forzó el rechazo de procesarPago) pero el checkout mostró éxito.");
      }
      if (!estadoClase(doc).includes("error") || texto.trim() === "") {
        throw new Error(`Se esperaba un mensaje de error del cobro (p. ej. que no se pudo conectar / fondos insuficientes); el estado mostrado fue: "${estadoTexto(doc)}".`);
      }
      return true;
    },
  },
  {
    id: "P5",
    nombre: "Compra exitosa: se llama a confirmarPedido, se muestra el número de pedido y se descuenta el stock",
    puntos: 15,
    async ejecutar(codigo) {
      // Math.random = 0.5 -> demora ≈ 3.15s (no timeout) y 0.5 no es
      // menor que la probabilidad de fallo (0.4 o 0.2), así que
      // procesarPago resuelve: toda la compra debería terminar en éxito.
      const doc = await buildSandbox(codigo, 0.5);
      await iniciarCompra(doc, { indiceProducto: 0, cantidad: 2, metodo: "paypal" });

      const stockAntesTexto = doc.querySelectorAll(".producto")[0].textContent;
      const stockAntes = parseInt((stockAntesTexto.match(/Stock:\s*(\d+)/) || [])[1], 10);
      if (Number.isNaN(stockAntes)) {
        throw new Error("No se pudo leer el stock inicial del primer producto (¿sigue mostrando 'Stock: N' dado en renderizarProductos?).");
      }

      click(doc.querySelector("#btn-finalizar"));
      await wait(4200);

      const texto = estadoTexto(doc);
      if (!/pedido\s*#\d+\s*confirmado/i.test(texto)) {
        throw new Error(`Se esperaba un mensaje de éxito con el número de pedido (ej. "¡Pedido #1234 confirmado! ..."); el estado mostrado fue: "${texto}".`);
      }
      if (!estadoClase(doc).includes("exito")) {
        throw new Error("El mensaje de éxito no se mostró con la clase de éxito (estado exito).");
      }

      const stockDespuesTexto = doc.querySelectorAll(".producto")[0].textContent;
      const stockDespues = parseInt((stockDespuesTexto.match(/Stock:\s*(\d+)/) || [])[1], 10);
      if (stockDespues !== stockAntes - 2) {
        throw new Error(`Tras comprar 2 unidades se esperaba que el stock bajara de ${stockAntes} a ${stockAntes - 2}; quedó en ${Number.isNaN(stockDespues) ? stockDespuesTexto : stockDespues}.`);
      }
      return true;
    },
  },
  {
    id: "P6",
    nombre: "finally: el botón se deshabilita durante el proceso y se vuelve a habilitar al terminar (éxito y error)",
    puntos: 10,
    async ejecutar(codigo) {
      const btnDeshabilitadoDuranteProceso = await (async () => {
        const doc = await buildSandbox(codigo, 0.5);
        await iniciarCompra(doc, { indiceProducto: 0, cantidad: 1, metodo: "paypal" });
        const boton = doc.querySelector("#btn-finalizar");
        click(boton);
        await wait(100);
        return boton.disabled;
      })();
      if (!btnDeshabilitadoDuranteProceso) {
        throw new Error("El botón #btn-finalizar no quedó deshabilitado nada más darle clic (debería deshabilitarse al iniciar realizarCheckout).");
      }

      // Caso de éxito.
      const docExito = await buildSandbox(codigo, 0.5);
      await iniciarCompra(docExito, { indiceProducto: 0, cantidad: 1, metodo: "paypal" });
      const botonExito = docExito.querySelector("#btn-finalizar");
      click(botonExito);
      await wait(4200);
      if (botonExito.disabled) {
        throw new Error("Tras una compra exitosa, el botón #btn-finalizar sigue deshabilitado (finally debería volver a habilitarlo).");
      }

      // Caso de error (cobro rechazado).
      const docError = await buildSandbox(codigo, 0);
      await iniciarCompra(docError, { indiceProducto: 0, cantidad: 1, metodo: "paypal" });
      const botonError = docError.querySelector("#btn-finalizar");
      click(botonError);
      await wait(900);
      if (botonError.disabled) {
        throw new Error("Tras una compra que falló, el botón #btn-finalizar sigue deshabilitado (finally debería volver a habilitarlo también en el error).");
      }
      return true;
    },
  },
  {
    id: "P7",
    nombre: "AbortController: procesarPago acepta una señal y se cancela; si gana el timeout, el cobro se aborta",
    puntos: 15,
    async ejecutar(codigo) {
      // Parte A: procesarPago por sí sola. Math.random = 0.99 -> el cobro
      // tardaría ~5.9s; si se aborta a los 100ms debe rechazar casi de
      // inmediato con un mensaje de cancelación.
      const docA = await buildSandbox(codigo, 0.99);
      const winA = docA.defaultView;
      if (typeof winA.procesarPago !== "function") {
        throw new Error("No se encontró la función procesarPago.");
      }
      const controladorA = new winA.AbortController();
      const promesa = winA.procesarPago(100, "paypal", controladorA.signal);
      let resultado = "pendiente";
      promesa.then(
        () => (resultado = "resolvió"),
        (e) => (resultado = e && e.message ? e.message : "rechazó")
      );
      await wait(100);
      controladorA.abort();
      await wait(200);
      if (resultado === "pendiente") {
        throw new Error("Tras abortar la señal, procesarPago no rechazó: debe escuchar el evento 'abort', hacer clearTimeout y rechazar con un Error 'Cobro cancelado'.");
      }
      if (resultado === "resolvió" || !/cancel/i.test(resultado)) {
        throw new Error(`Tras abortar, procesarPago debía rechazar con un Error que mencione la cancelación (ej. "Cobro cancelado"); resultado: "${resultado}".`);
      }

      // Parte B: dentro del checkout, si gana el timeout, la señal que se
      // le pasó a procesarPago debe quedar abortada.
      const docB = await buildSandbox(codigo, 0.99);
      const winB = docB.defaultView;
      const original = winB.procesarPago;
      let senalCapturada = null;
      winB.procesarPago = function (monto, metodo, senal) {
        senalCapturada = senal;
        return original(monto, metodo, senal);
      };
      await iniciarCompra(docB, { indiceProducto: 0, cantidad: 1, metodo: "paypal" });
      click(docB.querySelector("#btn-finalizar"));
      await wait(5700);

      if (!senalCapturada) {
        throw new Error("realizarCheckout no le pasó una señal (controlador.signal) a procesarPago como tercer argumento.");
      }
      if (!senalCapturada.aborted) {
        throw new Error("Cuando gana el timeout, el cobro debe cancelarse: llama a controlador.abort() en el finally del paso de la carrera.");
      }
      return true;
    },
  },
];

// ============================================================
// UI — checkbox (gris/rojo/verde) por punto, barra de progreso,
// botón para procesar todo, y botón "Probar" por punto.
// ============================================================

let score = null;
let barFill = null;

function construirChecklist() {
  const lista = document.getElementById("checklist");
  lista.innerHTML = "";
  pruebas.forEach((prueba) => {
    const li = document.createElement("li");
    li.className = "punto";
    li.innerHTML = `
      <button class="btnProbarUna" data-id="${prueba.id}">Probar</button>
      <input type="checkbox" />
      <label id="${prueba.id}">${prueba.nombre} (${prueba.puntos} pts)</label>
    `;
    lista.appendChild(li);
  });

  lista.querySelectorAll(".btnProbarUna").forEach((boton) => {
    boton.addEventListener("click", () => probarUna(boton.dataset.id));
  });
}

async function resetScore() {
  score.textContent = "0";
  barFill.style.width = "0%";
  document.querySelectorAll('#checklist input[type="checkbox"]').forEach((checkbox) => {
    checkbox.disabled = true;
    checkbox.checked = false;
  });
  document.querySelectorAll(".error-message").forEach((el) => el.remove());
  document.querySelector("#sandbox").innerHTML = "";
}

function marcarResultado(id, paso, mensajeError) {
  const label = document.querySelector(`#${id}`);
  const checkbox = label ? label.previousElementSibling : null;
  const previoError = label && label.nextElementSibling && label.nextElementSibling.classList.contains("error-message") ? label.nextElementSibling : null;
  if (previoError) previoError.remove();

  if (checkbox) {
    checkbox.disabled = true;
    checkbox.checked = paso;
  }
  if (!paso && mensajeError && label) {
    const errorDiv = document.createElement("div");
    errorDiv.classList.add("error-message");
    errorDiv.style.color = "red";
    errorDiv.textContent = mensajeError;
    label.insertAdjacentElement("afterend", errorDiv);
  }
}

function actualizarScore() {
  const total = pruebas.reduce((suma, prueba) => {
    const label = document.querySelector(`#${prueba.id}`);
    const checkbox = label ? label.previousElementSibling : null;
    return suma + (checkbox && checkbox.checked ? prueba.puntos : 0);
  }, 0);
  score.textContent = total;
  barFill.style.width = total + "%";
}

function leerCodigoFuente() {
  const codigo = document.getElementById("codeInput").value;
  return codigo.trim() ? codigo : null;
}

async function probarUna(id) {
  const codigoFuente = leerCodigoFuente();
  if (!codigoFuente) {
    alert("Sube el archivo checkout.js o pega el código en el cuadro de texto.");
    return;
  }
  const prueba = pruebas.find((p) => p.id === id);
  let paso = false;
  let error = "";
  try {
    paso = Boolean(await prueba.ejecutar(codigoFuente));
  } catch (e) {
    error = e.message;
  }
  marcarResultado(id, paso, error);
  actualizarScore();
}

async function procesarTodo() {
  const codigoFuente = leerCodigoFuente();
  if (!codigoFuente) {
    alert("Por favor, pega tu código en el área de texto.");
    return;
  }
  await resetScore();
  for (const prueba of pruebas) {
    let paso = false;
    let error = "";
    try {
      paso = Boolean(await prueba.ejecutar(codigoFuente));
    } catch (e) {
      error = e.message;
    }
    marcarResultado(prueba.id, paso, error);
    actualizarScore();
  }
}

document.addEventListener("DOMContentLoaded", () => {
  score = document.querySelector("#score");
  barFill = document.querySelector("#progress-bar-fill");
  construirChecklist();
  resetScore();

  document.getElementById("processCodeButton").addEventListener("click", procesarTodo);

  document.getElementById("fileinput").addEventListener("change", async (evt) => {
    const archivo = evt.target.files[0];
    if (!archivo) return;
    if (!archivo.name.toLowerCase().endsWith(".js")) {
      alert("Solo se aceptan archivos .js");
      evt.target.value = "";
      return;
    }
    document.getElementById("codeInput").value = await archivo.text();
    await procesarTodo();
  });
});
